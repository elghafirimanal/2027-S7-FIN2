"""
Analyse du taux de chômage au Maroc (2014-2025)
Source : HCP - Enquête nationale sur l'emploi (fichier extrait le 2026-09-28)

Ce script :
  1. importe le fichier Excel brut,
  2. le transforme en table "propre" (format long) -> data/chomage_maroc_propre.csv,
  3. calcule les indicateurs clés,
  4. génère les graphiques -> figures/.
Usage : python scripts/analyse_chomage.py
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

RACINE = Path(__file__).resolve().parent.parent
FICHIER = RACINE / "data" / "taux_chomage_HCP_2026-09-28.xlsx"
SORTIE_CSV = RACINE / "data" / "chomage_maroc_propre.csv"
DOSSIER_FIG = RACINE / "figures"
DOSSIER_FIG.mkdir(exist_ok=True)


def importer(fichier: Path) -> pd.DataFrame:
    """Lit le tableau HCP (en-têtes sur 2 lignes) et le met en format long."""
    brut = pd.read_excel(fichier, header=None)
    annees = [int(a) for a in brut.iloc[0, 3:].tolist()]
    donnees = brut.iloc[2:, :].copy()
    donnees.columns = ["milieu", "age", "sexe"] + annees
    donnees[["milieu", "age"]] = donnees[["milieu", "age"]].ffill()  # cellules fusionnées
    long = donnees.melt(id_vars=["milieu", "age", "sexe"],
                        var_name="annee", value_name="taux_chomage")
    long["annee"] = long["annee"].astype(int)
    long["taux_chomage"] = long["taux_chomage"].astype(float)
    return long.sort_values(["milieu", "age", "sexe", "annee"]).reset_index(drop=True)


def serie(df, milieu="National", age="15 ans et plus", sexe="Total"):
    s = df[(df.milieu == milieu) & (df.age == age) & (df.sexe == sexe)]
    return s.set_index("annee")["taux_chomage"]


def indicateurs(df):
    nat = serie(df)
    print("=== TAUX NATIONAL (15 ans et +) ===")
    print(nat.to_string())
    print(f"\nVariation 2014->2025 : {nat[2025]-nat[2014]:+.1f} pts")
    print(f"Variation 2019->2025 : {nat[2025]-nat[2019]:+.1f} pts")
    print(f"Pic : {nat.idxmax()} ({nat.max()} %)")
    print("Années de baisse :", [a for a in nat.index[1:] if nat[a] < nat[a-1]])
    print("\n=== ÉCARTS 2025 ===")
    for m in ["Urbain", "Rural"]:
        print(f"{m}: {serie(df, m)[2025]} % (2014 : {serie(df, m)[2014]} %)")
    for s in ["Masculin", "Feminin"]:
        print(f"{s}: {serie(df, sexe=s)[2025]} % (2014 : {serie(df, sexe=s)[2014]} %)")
    for a in ["15-24 ans", "25-34 ans", "35-44 ans", "45 ans et plus"]:
        print(f"{a}: {serie(df, age=a)[2025]} % (2014 : {serie(df, age=a)[2014]} %)")
    print("\n=== Féminin 15-24 ans (national) ===")
    print(serie(df, age="15-24 ans", sexe="Feminin")[[2014, 2019, 2025]].to_string())


def graphique_principal(df):
    """Graphique demandé : évolution du taux de chômage national, total et par sexe."""
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(serie(df).index, serie(df), "k-o", lw=2.5, label="Ensemble")
    ax.plot(serie(df, sexe="Feminin").index, serie(df, sexe="Feminin"), "-s", color="#c0392b", label="Femmes")
    ax.plot(serie(df, sexe="Masculin").index, serie(df, sexe="Masculin"), "-^", color="#2471a3", label="Hommes")
    ax.axvspan(2019.5, 2020.5, color="grey", alpha=.15)
    ax.text(2020, 5.5, "Covid-19", ha="center", fontsize=8, color="grey")
    ax.set_title("Taux de chômage au Maroc, 2014-2025 (15 ans et plus)")
    ax.set_ylabel("Taux de chômage (%)"); ax.set_xlabel("Année")
    ax.set_xticks(range(2014, 2026)); ax.set_ylim(5, 22); ax.grid(alpha=.3); ax.legend()
    fig.text(0.01, 0.005, "Source : HCP, Enquête nationale sur l'emploi (extraction du 28/09/2026)", fontsize=7)
    fig.tight_layout(rect=(0, 0.02, 1, 1))
    fig.savefig(DOSSIER_FIG / "01_chomage_national.png", dpi=200)


def graphique_decomposition(df):
    """4 panneaux : milieu, âge, jeunes par sexe, écart urbain/rural."""
    fig, axs = plt.subplots(2, 2, figsize=(12, 8))
    for m, c in [("Urbain", "#8e44ad"), ("Rural", "#27ae60"), ("National", "k")]:
        axs[0, 0].plot(serie(df, m).index, serie(df, m), "-o", color=c, label=m, ms=4)
    axs[0, 0].set_title("Par milieu de résidence")
    for a in ["15-24 ans", "25-34 ans", "35-44 ans", "45 ans et plus"]:
        axs[0, 1].plot(serie(df, age=a).index, serie(df, age=a), "-o", ms=4, label=a)
    axs[0, 1].set_title("Par groupe d'âge (national)")
    for s, c in [("Feminin", "#c0392b"), ("Masculin", "#2471a3")]:
        axs[1, 0].plot(serie(df, age="15-24 ans", sexe=s).index,
                       serie(df, age="15-24 ans", sexe=s), "-o", color=c, ms=4,
                       label="Femmes 15-24" if s == "Feminin" else "Hommes 15-24")
    axs[1, 0].set_title("Jeunes de 15-24 ans, par sexe")
    ecart = serie(df, "Urbain") - serie(df, "Rural")
    axs[1, 1].bar(ecart.index, ecart, color="#7f8c8d")
    axs[1, 1].set_title("Écart urbain - rural (points)")
    for ax in axs.flat:
        ax.grid(alpha=.3); ax.set_xticks(range(2014, 2026, 2)); ax.set_ylabel("%")
        if ax is not axs[1, 1]: ax.legend(fontsize=8)
    fig.suptitle("Décomposition du chômage au Maroc, 2014-2025", fontsize=13)
    fig.text(0.01, 0.005, "Source : HCP, Enquête nationale sur l'emploi (extraction du 28/09/2026)", fontsize=7)
    fig.tight_layout(rect=(0, 0.02, 1, 0.96))
    fig.savefig(DOSSIER_FIG / "02_decomposition.png", dpi=200)


if __name__ == "__main__":
    df = importer(FICHIER)
    df.to_csv(SORTIE_CSV, index=False, encoding="utf-8")
    print(f"{len(df)} observations exportées -> {SORTIE_CSV.name}\n")
    indicateurs(df)
    graphique_principal(df)
    graphique_decomposition(df)
    print("\nGraphiques enregistrés dans", DOSSIER_FIG)
